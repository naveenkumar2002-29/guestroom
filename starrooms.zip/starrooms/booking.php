<?php
include("connection.php");
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Room</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            padding: 20px;
        }

        table {
            width: 50%;
            margin: auto;
            border-collapse: collapse;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            overflow: hidden;
        }

        th, td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #f2f2f2;
            font-weight: bold;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        input[type="date"], input[type="submit"], input[type="text"] {
            width: 100%;
            padding: 10px;
            margin: 5px 0;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
    <script>
        function calculateTotalAmount() {
            const startDate = new Date(document.getElementById('start_date').value);
            const endDate = new Date(document.getElementById('end_date').value);
            const rent = parseFloat(document.getElementById('rent').value);
            const minDays = parseInt(document.getElementById('min_days').value);
            const maxDays = parseInt(document.getElementById('max_days').value);

            if (startDate && endDate && !isNaN(rent) && startDate <= endDate) {
                const timeDiff = endDate.getTime() - startDate.getTime();
                const dayDiff = Math.ceil(timeDiff / (1000 * 3600 * 24)) + 1; // +1 to include the start date

                if (dayDiff < minDays) {
                    alert(`The booking duration must be at least ${minDays} days.`);
                    document.getElementById('end_date').value = '';
                    document.getElementById('total_amount').value = '';
                    return;
                }
                
                if (dayDiff > maxDays) {
                    alert(`The booking duration must not exceed ${maxDays} days.`);
                    document.getElementById('end_date').value = '';
                    document.getElementById('total_amount').value = '';
                    return;
                }

                const totalAmount = dayDiff * rent;
                document.getElementById('total_amount').value = totalAmount.toFixed(2);
            } else {
                document.getElementById('total_amount').value = '';
            }
        }
    </script>
</head>
<body>
<?php
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $sql = "SELECT * FROM rooms WHERE room_id = $id";
    $query = mysqli_query($conn, $sql);    
    $data = mysqli_fetch_assoc($query);
?>
    <h1 style="text-align: center;">Book Room: <?php echo htmlspecialchars($data['room_no']); ?></h1>
    <table>
        <tr>
            <th>Room No</th>
            <td><?php echo htmlspecialchars($data['room_no']); ?></td>
        </tr>
        <tr>
            <th>Rent per Day</th>
            <td><input type="text" id="rent" value="<?php echo htmlspecialchars($data['rent']); ?>" readonly></td>
        </tr>
        <tr>
            <th>Room Type</th>
            <td><?php echo htmlspecialchars($data['room_type'] == 1 ? 'AC' : 'NON AC'); ?></td>
        </tr>
        <tr>
            <th>Members</th>
            <td><?php echo htmlspecialchars($data['members']); ?></td>
        </tr>
        <tr>
            <th>Description</th>
            <td><?php echo htmlspecialchars($data['description']); ?></td>
        </tr>
    </table>
    <form action="bookingquery.php" method="post" style="width: 50%; margin: auto; margin-top: 20px;"><?php echo $_SESSION['cus_id']; ?>
        <input type="hidden" name="room_id" value="<?php echo htmlspecialchars($id); ?>">
        <input type="hidden" name="cus_id" value="<?php echo $_SESSION['cus_id']; ?>">
        <input type="hidden" id="min_days" value="<?php echo htmlspecialchars($data['minum_days']); ?>">
        <input type="hidden" id="max_days" value="<?php echo htmlspecialchars($data['maximum_days']); ?>">
        <label for="start_date">Start Date:</label>
        <input type="date" id="start_date" name="start_date" required onchange="calculateTotalAmount()">
        <br>
        <label for="end_date">End Date:</label>
        <input type="date" id="end_date" name="end_date" required onchange="calculateTotalAmount()">
        <br>
        <label for="total_amount">Total Amount:</label>
        <input type="text" id="total_amount" name="total_amount" readonly>
        <br>
        <input type="submit" value="Book Room">
    </form>
<?php
}
?>
</body>
</html>
