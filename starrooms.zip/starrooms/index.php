<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Star Rooms Customer</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        h1 {
            text-align: center;
            margin-bottom: 443px; 
            margin-left:-153px;
        }

        .login-form {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 300px;
        }

        .form-title {
            text-align: center;
            margin-bottom: 15px;
            font-size: 1.5em;
        }

        .form-group {
            margin-bottom: 15px;
        }

        label {
            display: block;
            margin-bottom: 5px;
        }

        input[type="text"], input[type="password"] {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .form-actions {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            background-color: #28a745;
            color: #fff;
            cursor: pointer;
        }

        .btn:hover {
            background-color: #218838;
        }

        .rememberme {
            font-size: 0.9em;
        }

        #errorDisplay {
            color: red;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <h1>Star Rooms</h1>
    <form class="login-form" action="loginquery.php" method="post" id="loginForm">
        <h3 class="form-title">Sign In</h3>
        <div id="errorDisplay"></div>
        <?php
            session_start();
            if(isset($_SESSION['error'])): ?>
            <p style="color:red;"><?php echo ($_SESSION['error']); unset($_SESSION['error']); ?></p>
        <?php endif; ?>
        <div class="form-group">
            <label for="email">User Email</label>
            <input type="text" placeholder="Username" name="email" id="email"/>
        </div>
        <div class="form-group">
            <label for="password">Password</label>
            <input type="password" placeholder="Password" name="password" id="password"/>
            <span id="passwordError" style="color:red;"></span>
        </div>
        <div class="form-actions">
            <input class="btn" type="submit" name="submit" id="submitBtn" value="Sign In"/>
            <label class="rememberme">
                <input type="checkbox" name="remember" value="1"/> Remember
            </label>
        </div>
    </form>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#loginForm').submit(function(e) {
                var email = $('#email').val();
                var password = $('#password').val();
                var errorDisplay = $('#errorDisplay');

                if (email.trim() == '') {
                    errorDisplay.text('Username cannot be empty');
                    e.preventDefault();
                    return false;
                }

                if (password.trim() == '') {
                    errorDisplay.text('Password cannot be empty');
                    e.preventDefault();
                    return false;
                }

                if (password.length < 6) {
                    errorDisplay.text('Password must be at least 6 characters long');
                    e.preventDefault();
                    return false;
                }

                errorDisplay.text('');
            });
        });
    </script>
</body>
</html>
