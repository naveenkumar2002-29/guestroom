<?php
include("connection.php");
session_start();  
if (isset($_GET['id'])) {
    $_SESSION['room_id'] = $_GET['id'];
    echo "Room ID " . $_SESSION['room_id'] . " has been set in the session.";
} else {
    echo "No room ID provided.";
}

function sanitizeInput($data) {
    return htmlspecialchars(stripslashes(trim($data)));
}

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = sanitizeInput($_POST['action']);
    $room_no = sanitizeInput($_POST['room_no'] ?? '');
    $rent = sanitizeInput($_POST['rent'] ?? '');
    $minum_days = sanitizeInput($_POST['minum_days'] ?? '');
    $maximum_days = sanitizeInput($_POST['maximum_days'] ?? '');
    $room_type = sanitizeInput($_POST['room_type'] ?? '');
    $status = sanitizeInput($_POST['status'] ?? '');
    $members = sanitizeInput($_POST['members'] ?? '');
    $description = sanitizeInput($_POST['description'] ?? '');
    $image = $_FILES['image'];
    $image_name = '';
    

    // Handle single file upload
    if (!empty($image) && $image['error'] == 0) {
        $target_dir = 'uploads/';
        $image_name = basename($image['name']);
        if (!move_uploaded_file($image['tmp_name'], $target_dir . $image_name)) {
            echo "Error uploading image file.";
            exit();
        }
    } else {
        $image_name = sanitizeInput($_POST['old_image'] ?? '');
    }

    // Handle multiple file uploads
    $multi_image_names = [];
    if (!empty($_FILES['multi_image']['name'][0])) {
        foreach ($_FILES['multi_image']['name'] as $key => $name) {
            if ($_FILES['multi_image']['error'][$key] == 0) {
                $target_file = 'uploads/' . basename($name);
                if (move_uploaded_file($_FILES['multi_image']['tmp_name'][$key], $target_file)) {
                    $multi_image_names[] = basename($name);
                } else {
                    echo "Error uploading file: $name <br>";
                }
            }
        }
        $file_names_string = implode(',', $multi_image_names);
}else{
    $file_names_string = $_POST['multiold_image'];
}
    

    // If files uploaded, insert or update data in the database
    if ($action == "add" || $action == "edit") {
        if ($action == "add") {
          
                $query = "SELECT * from rooms where room_no = $room_no";
                $sql = mysqli_query($conn,$query);
                $row = mysqli_num_rows($sql);
                if($row > 0){
                    $_SESSION['room_exitis'] = "invalid room number";
                    header("location:roomadd.php");
                    exit;

            }else{
                $_SERVER['room_exitis'] = "";
            $query = "INSERT INTO rooms (room_id, room_no, rent, minum_days, maximum_days, status, room_type, members, description, image, multi_image) 
                      VALUES ( '$room_no', '$rent', '$minum_days', '$maximum_days', '$status', '$room_type', '$members', '$description', '$image_name', '$file_names_string')";
            }
    
            echo $query; exit;
    } else {
            $id = sanitizeInput($_POST['room_id']);
            $query = "UPDATE rooms SET room_no='$room_no', rent='$rent', minum_days='$minum_days', maximum_days='$maximum_days', room_type='$room_type', members='$members', description='$description', image='$image_name', multi_image='$file_names_string', status='$status' WHERE room_id='$id'";
        }

        if (mysqli_query($conn, $query)) {
            echo ($action == "add") ? "Data inserted successfully." : "Data updated successfully.";
        } else {
            echo "Error " . (($action == "add") ? "inserting" : "updating") . " data into database: " . mysqli_error($conn);
        }

        // Redirect after adding or editing data
        header("Location: owner.php");
        exit();
    }
}

// Check if the action is delete
if (isset($_GET['action']) && $_GET['action'] == "delete" && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $query = "DELETE FROM rooms WHERE room_id = '$id'";

    if (mysqli_query($conn, $query)) {
        $response = array('success' => true, 'message' => 'Room deleted successfully.');
        echo json_encode($response);
    } else {
        $response = array('success' => false, 'message' => 'Error deleting room: ' . mysqli_error($conn));
        echo json_encode($response);
    }

    header("Location: owner.php");
    exit();
}

// Redirect if the action is not delete
header("Location: owner.php");
exit();
?>
