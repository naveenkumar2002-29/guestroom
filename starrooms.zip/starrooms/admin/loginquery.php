<?php
include("connection.php");
session_start();

if (isset($_POST['submit'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Sanitize user input to prevent SQL injection
    $email = mysqli_real_escape_string($conn, $email);

    // Query to fetch user details
    $query = "SELECT * FROM owner WHERE email = '$email' and password = '$password'";
    //echo $query; exit;
    $result = mysqli_query($conn, $query);

    
}

header("Location: owner.php");

?>
