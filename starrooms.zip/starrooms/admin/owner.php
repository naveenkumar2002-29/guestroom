<?php
include('connection.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Room List</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 10px;
            border: 1px solid #ddd;
        }
        th {
            background-color: #f4f4f4;
        }
        .add-button {
            margin: 20px 0;
        }
    </style>
</head>
<body>
    <h1>Room List</h1>
    <div class="add-button">
        <a href="add_room.php"><button>Add New Room</button></a>
    </div>

    <table>
        <thead>
            <tr>
                <th>Room No</th>
                <th>Status</th>
                <th>Room Rent</th>
                <th>Minimum Days</th>
                <th>Maximum Days</th>
                <th>AC / Non AC</th>
                <th>Members</th>
                <th>Description</th>
                <th>Image</th>
            </tr>
        </thead>
        <tbody>
            <?php
             $sql = "SELECT * FROM rooms";
             $result = $conn->query($sql);
             if ($result->num_rows > 0) {

                while($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row["room_no"] . "</td>";
                    echo "<td>" . $row["status"] . "</td>";
                    echo "<td>" . $row["rent"] . "</td>";
                    echo "<td>" . $row["minum_days"] . "</td>";
                    echo "<td>" . $row["maximum_days"] . "</td>";
                    echo "<td>" . $row["room_type"] . "</td>";
                    echo "<td>" . $row["members"] . "</td>";
                    echo "<td>" . $row["description"] . "</td>";
                    echo "<td><img src='uploads/".$row["image"] . "' alt='Room Image' width='100'></td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='9'>No rooms found</td></tr>";
            }
            ?>
        </tbody>
    </table>
</body>
</html>

<?php
$conn->close();
?>