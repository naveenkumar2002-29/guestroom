<?php
include("connection.php");
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rooms</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin-top: 150px;
            padding: 20px;
        }

        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 500px;
            margin-top:200px;
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
        }

        .form-group {
            margin-bottom: 15px;
        }

        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        input[type="text"], input[type="number"], textarea, input[type="file"] {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .radio-group {
            display: flex;
            gap: 10px;
            align-items: center;
            margin-top: 5px;
        }

        .form-actions {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
        }

        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            background-color: #007bff;
            color: #fff;
            cursor: pointer;
            text-align: center;
        }

        .btn:hover {
            background-color: #0056b3;
        }

        .btn.default {
            background-color: #6c757d;
        }

        .btn.default:hover {
            background-color: #5a6268;
        }
    </style>
</head>
<body>
    <?Php
    if (isset($_GET['id'])){
            $id = $_GET['id'];
            $sql = "SELECT * FROM rooms WHERE room_id = $id";
            $query = mysqli_query($conn, $sql);    
            $data = mysqli_fetch_assoc($query);
            
        ?>
    <form action="roomaddquery.php" method="POST" enctype="multipart/form-data">
        <input type="hidden" name="action" value="edit">
        <input type="hidden" name="room_id" value="<?php echo $data['room_id'] ?>">
        <div class="form-body">            
 
            <div class="form-group">

                <label for="room_no">Room No</label>
              

                <input type="number" name="room_no" id="room_no" value="<?php echo $data["room_no"] ?>"placeholder="Enter Room Number" readonly>
            </div>
           
            <div class="form-group">
                <label for="rent">Room Rent</label>
                <input type="number" name="rent" id="rent" value="<?php echo $data["room_no"] ?>"  placeholder="Enter Room Rent">
            </div>
            <div class="form-group">
                <label for="minum_days">Room Booking Minimum Days</label>
                <input type="number" name="minum_days" id="minum_days" value="<?php echo $data["room_no"] ?>" placeholder="Enter Room Booking Minimum Days">
            </div>
            <div class="form-group">
                <label for="maximum_days">Room Booking Maximum Days</label>
                <input type="number" name="maximum_days" id="maximum_days" value="<?php echo $data["room_no"] ?>" placeholder="Enter Room Booking Maximum Days">
            </div>
            <div class="form-group">
    <label>Status</label>
    <div class="radio-group">
        <input id="option1" type="radio" name="status" value="1" <?php if($data['status'] == "1") { echo "checked"; } ?>>
        <label for="option1">Available</label>
        <input id="option2" type="radio" name="status" value="2" <?php if($data['status'] == "2") { echo "checked"; } ?>>
        <label for="option2">Booked</label>
    </div>
</div>
          
      <div class="form-group">
    <label>AC / Non AC</label>
    <div class="radio-group">
        <input id="option1" type="radio" name="room_type" value="1" <?php if($data['room_type'] == "1") { echo "checked"; } ?>>
        <label for="option1">AC</label>
        <input id="option2" type="radio" name="room_type" value="2" <?php if($data['room_type'] == "2") { echo "checked"; } ?>>
        <label for="option2">NON AC</label>
    </div>
</div>
            </div>
            <div class="form-group">
                <label for="members">Members</label>
                <input type="number" name="members" id="members" value="<?php echo $data["room_no"] ?>" placeholder="Enter Number of Members">
            </div>
            <div class="form-group">
    <label for="description">Description</label>
    <textarea name="description" id="description" placeholder="Enter description"><?php echo $data["description"]; ?></textarea>
</div>
            <div class="form-group">
                <label for="image">Room Image</label>
                <input type="file" name="image" >
                <input type="hidden" name="old_image" value="<?php echo $data['image'];?>">
				<img style="height:60px;width:90px;" src="uploads/<?php echo $data['image'] ?>" alt="imgs">

             <div class="form-group">
                <label for="image">Multi Room Image</label>
                <input type="file" name="oldimage[]" multiple>
                <?php
                $images = explode(',', $data['multi_image']);
                foreach ($images as $image) {
                    echo "<img height='80px' width='80px'src='uploads/$image' alt='img' class='zoomable' onmouseover='showImage(\"admin/uploads/$image\")'>";
                }
                ?>    </div>
        </div>
        <div class="form-actions">
            <button type="submit" name="submit" class="btn">Submit</button>
            <a href="owner.php"><button type="button" class="btn default">Cancel</button></a>
        </div>
    </form>
    <?php
    } else {
    ?>
    <form action="roomaddquery.php" method="POST" enctype="multipart/form-data">
        <input type="hidden" name="action" value="add"> 
        <div class="form-body">

            <div class="form-group">
                <label for="room_no">Room No</label>

                <input type="number" name="room_no" id="room_no" placeholder="Enter Room Number">
            </div>
           
            <div class="form-group">
                <label for="rent">Room Rent</label>
                <input type="number" name="rent" id="rent" placeholder="Enter Room Rent">
            </div>
            <div class="form-group">
                <label for="minum_days">Room Booking Minimum Days</label>
                <input type="number" name="minum_days" id="minum_days" placeholder="Enter Room Booking Minimum Days">
            </div>
            <div class="form-group">
                <label for="maximum_days">Room Booking Maximum Days</label>
                <input type="number" name="maximum_days" id="maximum_days" placeholder="Enter Room Booking Maximum Days">
            </div> <div class="form-group">
    <label>Status</label>
    <div class="radio-group">
        <input id="option1" type="radio" name="status" value="Available" >
        <label for="option1">Available</label>
        <input id="option2" type="radio" name="status" value="Booked" >
        <label for="option2">Booked</label></div>
    </div>
            <div class="form-group">
                <label>AC / Non AC</label>
                <div class="radio-group">
                    <input id="option1" type="radio" name="room_type" value="AC">
                    <label for="option1">AC</label>
                    <input id="option2" type="radio" name="room_type" value="NON AC">
                    <label for="option2">NON AC</label>
                </div>
            </div>
            <div class="form-group">
                <label for="members">Members</label>
                <input type="number" name="members" id="members" placeholder="Enter Number of Members">
            </div>
            <div class="form-group">
                <label for="description">Description</label>
                <textarea name="description" id="description" placeholder="Enter description"></textarea>
            </div>
            <div class="form-group">
                <label for="image">Room Image</label>
                <input type="file" name="image" >
            </div>
            <div class="form-group">
                <label for="image">Multi Room Image</label>
                <input type="file" name="multi_image[]" multiple>
            </div>
        </div>
        <div class="form-actions">
            <button type="submit" name="submit" class="btn">Submit</button>
            <a href="owner.php"><button type="button" class="btn default">Cancel</button></a>
        </div>
    </form>
    <?php
    }
    ?>
</body>
</html>
