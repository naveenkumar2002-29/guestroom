<?php
include("connection.php");
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Sanitize and escape input data
    $room_id = mysqli_real_escape_string($conn, $_POST['room_id']);
    $cus_id = mysqli_real_escape_string($conn, $_POST['cus_id']);
    $start_date = mysqli_real_escape_string($conn, $_POST['start_date']);
    $end_date = mysqli_real_escape_string($conn, $_POST['end_date']);
    $total_amount = mysqli_real_escape_string($conn, $_POST['total_amount']);
    $status = "0";

    // Insert booking details into the database
    $sql = "INSERT INTO booking (room_id, cus_id, start_date, end_date, total) VALUES ('$room_id', '$cus_id', '$start_date', '$end_date', '$total_amount')";
    if (mysqli_query($conn, $sql)) {
        // Update room status
        $query1 = "UPDATE rooms SET status='$status' WHERE room_id='$room_id'";
        if (mysqli_query($conn, $query1)) {
            echo "Room booked successfully!";
        } else {
            echo "Error updating room status: " . mysqli_error($conn);
        }
    } else {
        echo "Error: " . mysqli_error($conn);
    }

    // Redirect to a confirmation or another page
    header("Location: roomdetails.php");
    exit();
}
?>
