<?php
include("connection.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Room Images</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 1200px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        th, td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #f2f2f2;
        }
        img.zoomable {
            cursor: pointer;
            transition: transform 0.2s;
        }
        img.zoomable:hover {
            transform: scale(1.2);
        }
        .image-preview {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            max-width: 90%;
            max-height: 90%;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
            z-index: 1000;
        }
        .image-preview img {
            width: 100%;
            height: auto;
            border-radius: 8px;
        }
        .overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.7);
            z-index: 999;
        }
    </style>
    <script>
        function showImage(src) {
            document.querySelector('.image-preview img').src = src;
            document.querySelector('.overlay').style.display = 'block';
            document.querySelector('.image-preview').style.display = 'block';
        }

        function hideImage() {
            document.querySelector('.overlay').style.display = 'none';
            document.querySelector('.image-preview').style.display = 'none';
        }
    </script>
</head>
<body>

<div class="container">
    <?php
    if (isset($_GET['id'])) {
        $id = $_GET['id'];
        $sql = "SELECT * FROM rooms WHERE room_id = $id";
        $query = mysqli_query($conn, $sql);
        $data = mysqli_fetch_assoc($query);
    ?>
    <h1>Room Images</h1>
    <table>
        <tr><th>Images</th></tr>
        <tr>
            <td>
                <?php
                $images = explode(',', $data['multi_image']);
                foreach ($images as $image) {
                    echo "<img height='80px' width='80px'src='admin/uploads/$image' alt='img' class='zoomable' onmouseover='showImage(\"admin/uploads/$image\")'>";
                }
                ?>
            </td>
        </tr>
    </table>
    <?php } ?>
</div>

<div class="overlay" onclick="hideImage()"></div>
<div class="image-preview" onclick="hideImage()">
    <img src="" alt="Preview">
</div>

</body>
</html>
