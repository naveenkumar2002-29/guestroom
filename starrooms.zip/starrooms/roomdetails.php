<?php
include("connection.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome Star Rooms</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            padding: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        th, td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #f2f2f2;
            font-weight: bold;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        img {
            border-radius: 4px;
        }
    </style>
</head>
<body>
    <h1>Star Rooms</h1>
    <table class="table table-striped table-hover table-bordered" id="sample_editable_1">
        <thead>
            <tr>
                <th>Room No</th>
                <th>Owner</th>
                <th>Room Rent</th>
                <th>Booking Status</th>
                <th>Next Available Date</th>
                <th>AC / Non AC</th>
                <th>Members</th>
                <th>Description</th>
                <th>Image</th>
            </tr>
        </thead>
        <tbody>
            <?php
       
$sql = "
SELECT 
    rooms.room_id,
    rooms.room_no,
    rooms.owner_id,
    rooms.rent,
    rooms.status,
    rooms.room_type,
    rooms.members,
    rooms.description,
    rooms.image,
    booking.start_date,
    booking.end_date,
    COALESCE(owner.name, 'Unknown Owner') AS owner_name
FROM 
    rooms
LEFT JOIN 
    booking ON rooms.room_id = booking.room_id
        AND booking.end_date = (
            SELECT MAX(end_date) 
            FROM booking b 
            WHERE b.room_id = rooms.room_id
        )
LEFT JOIN 
    owner ON rooms.owner_id = owner.owner_id
ORDER BY 
    rooms.room_no;
";
            $query = mysqli_query($conn, $sql);
            while ($data = mysqli_fetch_assoc($query)) {
                $availableDate = '';
                if ($data['status'] == "1") {
                    $availableDate = "Available";
                } else if ($data['end_date']) {
                    $availableDate = date('Y-m-d', strtotime($data['end_date'] . ' + 1 days'));
                } else {
                    $availableDate = "N/A";
                }
            ?>
            <tr>
                <td><?php echo htmlspecialchars($data["room_no"]); ?></td>
                <td><?php echo  htmlspecialchars($data["owner_name"]); ?></td>
                <td><?php echo htmlspecialchars($data["rent"]); ?></td>
                <td><?php echo ($data['status'] == "1") ? "<a href='booking.php?id=" . $data['room_id'] . "'>Available</a>" : "Booked"; ?></td>
                <td><?php echo $availableDate; ?></td>
                <td><?php echo $data["room_type"] == 1 ? 'AC' : 'NON AC'; ?></td>
                <td><?php echo htmlspecialchars($data["members"]); ?></td>
                <td><?php echo htmlspecialchars($data["description"]); ?></td>
                <td><a href="viewimages.php?id=<?php echo htmlspecialchars($data['room_id']); ?>"><img height='50' width='50' src="admin/uploads/<?php echo htmlspecialchars($data['image']); ?>" alt="img"></a></td>
            </tr> 
            <?php
            }
            ?>
        </tbody>
    </table>
</body>
</html>
