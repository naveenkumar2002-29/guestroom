<?php
include("connection.php");


if (isset($_POST['submit'])) 
{
    $name = $_POST['name'];
    $email = $_POST['email'];
    //echo $sql;exit;
    $mobile = $_POST['mobile'];
    $password = $_POST['password'];
  

    $sql = "INSERT INTO customer (name,email, mobile, password) VALUES ('$name','$email', '$mobile', '$password')";

    if ($conn->query($sql) === TRUE) {
        $message = "New record created successfully";
    } else {
        $message = "Error: " . $sql . "<br>" . $conn->error;
    }
}
$conn->close();
header("Location: index.php");
?>
