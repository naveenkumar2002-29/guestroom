<?php
include("connection.php");
session_start();



if (isset($_POST['submit'])) {
    // Get the submitted email and password
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Perform validation on the email
    

    // Construct SQL query
    $sql = "SELECT * FROM customer WHERE email='" . $email . "' AND password='" . $password . "'";
    //echo $sql;exit;
    $result = mysqli_query($conn, $sql);

    // Check if the query was successful
    
        // Check if any rows were returned
        if (mysqli_num_rows($result) > 0) {
            $data = mysqli_fetch_assoc($result);
            $_SESSION['cus_id'] = $data['cus_id'];
            $_SESSION['email'] = $data['email'];
            $_SESSION['password'] = $data['password'];
            header("location: roomdetails.php");
            exit();
        } else {
            // Invalid Email or Password, redirect back to login page with error message
            $_SESSION['error'] = 'Invalid Email or Password';
            header("location: index.php");
            exit();
        }
 
    }                                                                                                                                                 

?>
